# 21 Blackjack Android build

This folder contains:

- `android/` — the native Android WebView project
- `public/` — the bundled game UI
- `server.js` — the multiplayer Node.js / Socket.IO server
- `public/socket.io.min.js` — the bundled Socket.IO browser client

## Run the multiplayer server

The APK contains the UI, but the game rules and multiplayer rooms still run
in Node.js. Start the server on a computer or deploy it to a Node.js host:

```bash
npm install
npm start
```

Then open the APK and enter the server address in the **Game server URL**
field. Use `http://10.0.2.2:3000` for an Android emulator, or the computer's
LAN address such as `http://192.168.1.20:3000` for a phone on the same Wi-Fi.
For production, use the HTTPS URL of the deployed server.

## Build the Android app

```bash
npm install
npm run android:build
```

The Android build uses the Gradle wrapper and Java 17 or newer.

The debug APK is generated at:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

The debug APK is suitable for testing and sideloading. Publishing to Google
Play requires a release signing key and a signed release build.